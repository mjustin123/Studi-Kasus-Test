<?php
class Vendor extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('tagihan_m');
        $this->load->model('item_m');
        if ($this->session->userdata('role') != 'vendor') {
            redirect('auth/login');
        }
    }

    // Dashboard vendor
    public function dashboard()
    {
        $id_vendor = $this->session->userdata('id_vendor');

        $data['title'] = 'Dashboard Vendor';
        $data['tagihan'] = $this->tagihan_m->get_by_vendor($id_vendor);

        // Optional summary
        $data['total_tagihan'] = array_sum(array_column((array)$data['tagihan'], 'total_tagihan'));
        $data['total_draft'] = count(array_filter($data['tagihan'], fn($t) => $t->status_verifikasi == 'draft'));
        $data['total_confirmed'] = count(array_filter($data['tagihan'], fn($t) => $t->status_verifikasi == 'confirmed'));

        $this->load->view('layout', [
            'contents' => $this->load->view('vendor/dashboard', $data, true)
        ]);
    }

    public function tagihan(){
        $id_vendor = $this->session->userdata('id_vendor');
        $data['title'] = 'Tagihan Saya';
        $data['tagihan'] = $this->tagihan_m->get_by_vendor($id_vendor);

        $this->load->view('layout', [
            'contents' => $this->load->view('vendor/tagihan_list', $data, true)
        ]);
    }

    // Konfirmasi tagihan (ubah status draft -> confirmed)
    public function confirm($id_tagihan){
        $id_vendor = $this->session->userdata('id_vendor');

        // Pastikan tagihan milik vendor ini
        $tagihan = $this->tagihan_m->get_by_vendor($id_vendor);
        $tagihan_ids = array_column((array)$tagihan, 'id_tagihan');
        if(!in_array($id_tagihan, $tagihan_ids)){
            show_error('Akses ditolak', 403);
        }

        // Update status
        $this->tagihan_m->update_tagihan($id_tagihan, ['status_verifikasi' => 'confirmed']);
        $this->session->set_flashdata('success','Tagihan berhasil dikonfirmasi');
        redirect('vendor/tagihan');
    }

    // Tambah tagihan
    public function tagihan_add(){
        $id_vendor = $this->session->userdata('id_vendor');
    
        $items_master = $this->item_m->get_all(); // Ambil semua item aktif
        $data['items'] = $items_master;
    
        if($this->input->post()){
            // Upload lampiran
            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'pdf|jpg|png|jpeg';
            $config['max_size'] = 2048;
            $this->load->library('upload', $config);
    
            $file_name = null;
            if($this->upload->do_upload('lampiran')){
                $file_name = $this->upload->data('file_name');
            }
    
            // Generate nomor tagihan otomatis
            $date = date('Ymd');
            $lastTagihan = $this->db->like('nomor_tagihan', 'TG-'.$date, 'after')
                                    ->order_by('id_tagihan','DESC')
                                    ->get('tagihan')
                                    ->row();
            if($lastTagihan){
                $lastNumber = (int) substr($lastTagihan->nomor_tagihan, -4);
                $newNumber = str_pad($lastNumber + 1, 4, '0', STR_PAD_LEFT);
            } else {
                $newNumber = '0001';
            }
            $nomor_tagihan = 'TG-'.$date.'-'.$newNumber;
    
            // Insert tagihan
            $tagihan_data = [
                'nomor_tagihan' => $nomor_tagihan,
                'tanggal_tagihan' => $this->input->post('tanggal_tagihan'),
                'id_vendor' => $id_vendor,
                'total_tagihan' => 0,
                'status_verifikasi' => 'draft',
                'file_lampiran' => $file_name
            ];
            $id_tagihan = $this->tagihan_m->insert_tagihan($tagihan_data);
    
            // Insert item
            $items = $this->input->post('item');   // berisi id_item dari dropdown
            $jumlahs = $this->input->post('jumlah');
            $harga_input = $this->input->post('harga');
            $total = 0;
    
            foreach($items as $k => $id_item){
                if(!$id_item) continue;
                $item_master = $this->db->get_where('master_item',['id_item'=>$id_item])->row();
                if(!$item_master) continue;
    
                $data_item = [
                    'id_tagihan' => $id_tagihan,
                    'id_item' => $id_item,
                    'nama_item' => $item_master->nama_item,
                    'jumlah' => $jumlahs[$k],
                    'harga' => $harga_input[$k]
                ];
                $total += $jumlahs[$k]*$harga_input[$k];
                $this->tagihan_m->insert_item($data_item);
            }
    
            // Update total tagihan
            $this->tagihan_m->update_tagihan($id_tagihan,['total_tagihan'=>$total]);
    
            $this->session->set_flashdata('success','Tagihan berhasil dibuat');
            redirect('vendor/tagihan');
        }
    
        $data['title'] = 'Tambah Tagihan';
        $this->load->view('layout', [
            'contents' => $this->load->view('vendor/tagihan_form', $data, true)
        ]);
    }

    public function tagihan_edit($id_tagihan){
        $id_vendor = $this->session->userdata('id_vendor');
        $tagihan = $this->tagihan_m->get($id_tagihan);
    
        if(!$tagihan || $tagihan->id_vendor != $id_vendor){
            show_404();
        }
    
        if($tagihan->status_verifikasi == 'confirmed'){
            $this->session->set_flashdata('error','Tagihan sudah dikonfirmasi, tidak bisa diubah');
            redirect('vendor/tagihan');
        }
    
        $data['items'] = $this->item_m->get_all();
        $data['tagihan'] = $tagihan;
        $data['tagihan_items'] = $this->tagihan_m->get_items($id_tagihan);
    
        if($this->input->post()){
    
            // === HANDLE LAMPIRAN BARU ===
            $lampiran = $tagihan->lampiran; // default tetap file lama
    
            if(!empty($_FILES['lampiran']['name'])){
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'pdf|jpg|jpeg|png';
                $config['max_size'] = 3000;
    
                $this->load->library('upload', $config);
    
                if($this->upload->do_upload('lampiran')){
                    $uploadData = $this->upload->data();
                    $lampiran = $uploadData['file_name'];
    
                    // hapus file lama
                    if(!empty($tagihan->lampiran) && file_exists('./uploads/'.$tagihan->file_lampiran)){
                        unlink('./uploads/'.$tagihan->file_lampiran);
                    }
                }
            }
    
            // === UPDATE TAGIHAN HEADER ===
            $tagihan_data = [
                'tanggal_tagihan' => $this->input->post('tanggal_tagihan'),
                'file_lampiran'        => $lampiran
            ];
            $this->tagihan_m->update_tagihan($id_tagihan,$tagihan_data);
    
            // === UPDATE DETAIL ITEM ===
            $this->tagihan_m->delete_items($id_tagihan);
    
            $items  = $this->input->post('item');
            $jumlah = $this->input->post('jumlah');
            $harga  = $this->input->post('harga');
    
            $total = 0;
    
            foreach($items as $k => $id_item){
                if(!$id_item) continue;
    
                $item_master = $this->db->get_where('master_item',['id_item'=>$id_item])->row();
                if(!$item_master) continue;
    
                $data_item = [
                    'id_tagihan' => $id_tagihan,
                    'id_item' => $id_item,
                    'nama_item' => $item_master->nama_item,
                    'jumlah' => $jumlah[$k],
                    'harga' => $harga[$k]
                ];
    
                $total += $jumlah[$k] * $harga[$k];
                $this->tagihan_m->insert_item($data_item);
            }
    
            $this->tagihan_m->update_tagihan($id_tagihan,[
                'total_tagihan' => $total
            ]);
    
            $this->session->set_flashdata('success','Tagihan berhasil diperbarui');
            redirect('vendor/tagihan');
        }
    
        $data['title'] = 'Edit Tagihan';
        $this->load->view('layout', [
            'contents' => $this->load->view('vendor/tagihan_form', $data, true)
        ]);
    }
    
    
}
