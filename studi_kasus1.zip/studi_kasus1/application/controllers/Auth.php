<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('user_m');
    }

    // ===== Login Form =====
    public function index() {
        if($this->session->userdata('id_user')){
            redirect($this->redirect_by_role($this->session->userdata('role')));
        }

        if($this->input->post()){
            $username = $this->input->post('username');
            $password = $this->input->post('password');

            $user = $this->user_m->get_by_username($username);
            if($user && password_verify($password, $user->password)){
                // Set session
                $this->session->set_userdata([
                    'id_user' => $user->id_user,
                    'username' => $user->username,
                    'nama_lengkap' => $user->nama_lengkap,
                    'role' => $user->role,
                    'id_vendor' => $user->id_vendor
                ]);
                redirect($this->redirect_by_role($user->role));
            } else {
                $data['error'] = 'Username atau password salah';
            }
        }

        $data['title'] = 'Login';
        $this->load->view('login', $data);
    }

    private function redirect_by_role($role) {
        if($role == 'admin') return 'admin/dashboard';
        if($role == 'vendor') return 'vendor/dashboard';
        return 'auth';
    }

    // ===== Logout =====
    public function logout() {
        $this->session->sess_destroy();
        redirect('auth');
    }
}
