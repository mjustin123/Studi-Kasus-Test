<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('vendor_m');
        $this->load->model('item_m');
        $this->load->model('tagihan_m');
        $this->load->model('user_m');

        // Cek login & role admin
        if($this->session->userdata('role') != 'admin'){
            redirect('auth/login');
        }
    }

    // ===================== Dashboard =====================
    public function dashboard() {
        $data['title'] = 'Dashboard Admin';
                // Filter tanggal
                $start_date = $this->input->get('start_date');
                $end_date = $this->input->get('end_date');
        $data['tagihan'] = $this->tagihan_m->get_all_verified($start_date,$end_date);

        // Chart per vendor
        $data['chart_data'] = $this->tagihan_m->get_chart_data($start_date,$end_date);

        // Summary
        $data['total_vendor'] = $this->db->count_all('vendor');
        $data['total_item'] = $this->db->count_all('master_item');
        $data['total_tagihan'] = $this->db->get_where('tagihan',['status_verifikasi'=>'confirmed'])->num_rows();
    
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/dashboard', $data, true)
        ]);
    }

    public function export_tagihan(){
        $start_date = $this->input->get('start_date');
        $end_date = $this->input->get('end_date');

        $this->load->dbutil();
        $this->load->helper('download');

        $this->db->select('t.nomor_tagihan, t.tanggal_tagihan, v.nama_vendor, t.total_tagihan');
        $this->db->from('tagihan t');
        $this->db->join('vendor v','v.id_vendor=t.id_vendor');
        $this->db->where('t.status_verifikasi','confirmed');
        if($start_date) $this->db->where('t.tanggal_tagihan >=', $start_date);
        if($end_date) $this->db->where('t.tanggal_tagihan <=', $end_date);

        $query = $this->db->get();
        $csv = $this->dbutil->csv_from_result($query);

        force_download('tagihan.csv', $csv);
    }

    // ===================== Vendor =====================
    public function vendor() {
        $data['vendors'] = $this->vendor_m->get_all();
        $data['title'] = 'Master Vendor';
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/vendor_list', $data, true)
        ]);
    }

    public function vendor_add() {
        if($this->input->post()){
            $this->vendor_m->insert($this->input->post());
            redirect('admin/vendor');
        }
        $data['title'] = 'Tambah Vendor';
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/vendor_form', $data, true)
        ]);
    }

    public function vendor_edit($id) {
        if($this->input->post()){
            $this->vendor_m->update($id, $this->input->post());
            redirect('admin/vendor');
        }
        $data['vendor'] = $this->vendor_m->get($id);
        $data['title'] = 'Edit Vendor';
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/vendor_form', $data, true)
        ]);
    }

    public function vendor_delete($id) {
        $this->vendor_m->delete($id);
        redirect('admin/vendor');
    }

    // ===================== Master Item =====================
    public function item() {
        $data['items'] = $this->item_m->get_all();
        $data['title'] = 'Master Item';
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/item_list', $data, true)
        ]);
    }

    public function item_add() {
        if($this->input->post()){
            $this->item_m->insert($this->input->post());
            redirect('admin/item');
        }
        $data['title'] = 'Tambah Item';
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/item_form', $data, true)
        ]);
    }

    public function item_edit($id) {
        if($this->input->post()){
            $this->item_m->update($id, $this->input->post());
            redirect('admin/item');
        }
        $data['item'] = $this->item_m->get($id);
        $data['title'] = 'Edit Item';
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/item_form', $data, true)
        ]);
    }

    public function item_delete($id) {
        $this->item_m->delete($id);
        redirect('admin/item');
    }

    public function user() {
        $data['title'] = 'Master User';
        $data['users'] = $this->user_m->get_all();
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/user_list', $data, true)
        ]);
    }
    
    public function user_add() {    
        if($this->input->post()){
            $data = [
                'username' => $this->input->post('username'),
                'nama_lengkap' => $this->input->post('nama_lengkap'),
                'password' => $this->input->post('password'),
                'role' => $this->input->post('role'),
                'id_vendor' => $this->input->post('id_vendor') ?: null,
                'status' => $this->input->post('status')
            ];
            $this->user_m->insert($data);
            redirect('admin/user');
        }
    
        $data['title'] = 'Tambah User';
        $data['vendors'] = $this->vendor_m->get_all(); // buat dropdown vendor
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/user_form', $data, true)
        ]);
    }
    
    public function user_edit($id) {
        $user = $this->user_m->get_by_id($id);
        if(!$user) show_404();
    
        if($this->input->post()){
            $data = [
                'username' => $this->input->post('username'),
                'nama_lengkap' => $this->input->post('nama_lengkap'),
                'password' => $this->input->post('password'),
                'role' => $this->input->post('role'),
                'id_vendor' => $this->input->post('id_vendor') ?: null,
                'status' => $this->input->post('status')
            ];
            $this->user_m->update($id, $data);
            redirect('admin/user');
        }
    
        $data['title'] = 'Edit User';
        $data['user'] = $user;
        $data['vendors'] = $this->vendor_m->get_all();
        $this->load->view('layout', [
            'contents' => $this->load->view('admin/user_form', $data, true)
        ]);
    }
    
    public function user_delete($id) {
        $this->user_m->delete($id);
        redirect('admin/user');
    }
}
