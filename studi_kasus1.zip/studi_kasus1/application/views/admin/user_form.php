<div class="container-fluid mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><?= isset($user) ? 'Edit User' : 'Tambah User' ?></h4>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" name="username" id="username" class="form-control" value="<?= $user->username ?? '' ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                            <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" value="<?= $user->nama_lengkap ?? '' ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label"><?= isset($user) ? 'Password (kosongkan jika tidak diganti)' : 'Password' ?></label>
                            <input type="password" name="password" id="password" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <select name="role" id="role" class="form-select" required>
                                <option value="admin" <?= (isset($user) && $user->role=='admin')?'selected':'' ?>>Admin</option>
                                <option value="vendor" <?= (isset($user) && $user->role=='vendor')?'selected':'' ?>>Vendor</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="id_vendor" class="form-label">Vendor (jika role vendor)</label>
                            <select name="id_vendor" id="id_vendor" class="form-select">
                                <option value="">-- Pilih Vendor --</option>
                                <?php foreach($vendors as $v): ?>
                                    <option value="<?= $v->id_vendor ?>" <?= (isset($user) && $user->id_vendor==$v->id_vendor)?'selected':'' ?>><?= $v->nama_vendor ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" id="status" class="form-select" required>
                                <option value="aktif" <?= (isset($user) && $user->status=='aktif')?'selected':'' ?>>Aktif</option>
                                <option value="nonaktif" <?= (isset($user) && $user->status=='nonaktif')?'selected':'' ?>>Nonaktif</option>
                            </select>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success"><?= isset($user) ? 'Update' : 'Simpan' ?></button>
                            <a href="<?= site_url('admin/user') ?>" class="btn btn-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
