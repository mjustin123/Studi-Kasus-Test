<div class="container-fluid mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><?= isset($item) ? 'Edit Item' : 'Tambah Item' ?></h4>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <div class="mb-3">
                            <label for="kode_item" class="form-label">Kode Item</label>
                            <input type="text" name="kode_item" id="kode_item" class="form-control" value="<?= $item->kode_item ?? '' ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="nama_item" class="form-label">Nama Item</label>
                            <input type="text" name="nama_item" id="nama_item" class="form-control" value="<?= $item->nama_item ?? '' ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="satuan" class="form-label">Satuan</label>
                            <input type="text" name="satuan" id="satuan" class="form-control" value="<?= $item->satuan ?? '' ?>">
                        </div>

                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga</label>
                            <input type="number" name="harga" id="harga" class="form-control" value="<?= $item->harga ?? 0 ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" id="status" class="form-select">
                                <option value="aktif" <?= (isset($item) && $item->status=='aktif')?'selected':'' ?>>Aktif</option>
                                <option value="nonaktif" <?= (isset($item) && $item->status=='nonaktif')?'selected':'' ?>>Nonaktif</option>
                            </select>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success">
                                <?= isset($item) ? 'Update' : 'Simpan' ?>
                            </button>
                            <a href="<?= site_url('admin/item') ?>" class="btn btn-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
