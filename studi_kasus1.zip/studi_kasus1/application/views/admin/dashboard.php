<div class="container-fluid">
    <h3 class="mb-4"><i class="bi bi-speedometer2 me-2"></i>Dashboard Admin</h3>

    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0 text-white bg-primary h-100">
                <div class="card-body d-flex align-items-center">
                    <i class="bi bi-people-fill fs-1 me-3"></i>
                    <div>
                        <h6 class="card-title">Total Vendor</h6>
                        <h4><?= $total_vendor ?></h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0 text-white bg-success h-100">
                <div class="card-body d-flex align-items-center">
                    <i class="bi bi-box-seam fs-1 me-3"></i>
                    <div>
                        <h6 class="card-title">Total Item</h6>
                        <h4><?= $total_item ?></h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="card shadow-sm border-0 text-white bg-warning h-100">
                <div class="card-body d-flex align-items-center">
                    <i class="bi bi-receipt fs-1 me-3"></i>
                    <div>
                        <h6 class="card-title">Total Tagihan</h6>
                        <h4><?= $total_tagihan ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter tanggal + Export -->
    <div class="card mb-4 shadow-sm">
        <div class="card-body">
            <form method="get" class="row g-2 align-items-center">
                <div class="col-md-3">
                    <input type="date" name="start_date" class="form-control" value="<?= $this->input->get('start_date') ?>" placeholder="Tanggal Mulai">
                </div>
                <div class="col-md-3">
                    <input type="date" name="end_date" class="form-control" value="<?= $this->input->get('end_date') ?>" placeholder="Tanggal Akhir">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100"><i class="bi bi-funnel me-1"></i> Filter</button>
                </div>
                <div class="col-md-2">
                    <a href="<?= site_url('admin/export_tagihan?start_date='.$this->input->get('start_date').'&end_date='.$this->input->get('end_date')) ?>" class="btn btn-success w-100"><i class="bi bi-download me-1"></i> Export CSV</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Chart per vendor -->
    <div class="card mb-4 shadow-sm">
        <div class="card-header bg-secondary text-white">
            <i class="bi bi-bar-chart-fill me-2"></i> Total Tagihan per Vendor
        </div>
        <div class="card-body">
            <canvas id="chartTagihan"></canvas>
        </div>
    </div>

    <!-- List Tagihan Terverifikasi -->
    <div class="card shadow-sm mb-4">
        <div class="card-header bg-dark text-white">
            <i class="bi bi-table me-2"></i> Daftar Tagihan Terverifikasi
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Nomor Tagihan</th>
                        <th>Tanggal</th>
                        <th>Vendor</th>
                        <th>Total</th>
                        <th>Lampiran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($tagihan as $t): ?>
                        <tr>
                            <td><?= $t->nomor_tagihan ?></td>
                            <td><?= $t->tanggal_tagihan ?></td>
                            <td><?= $t->nama_vendor ?></td>
                            <td><?= number_format($t->total_tagihan,0,",",".") ?></td>
                            <td>
                                <?php if($t->file_lampiran): ?>
                                    <a href="<?= base_url('uploads/'.$t->file_lampiran) ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-file-earmark-text me-1"></i> Lihat
                                    </a>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
const ctx = document.getElementById('chartTagihan').getContext('2d');
const chartTagihan = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: [<?php foreach($chart_data as $c){ echo "'$c->nama_vendor',"; } ?>],
        datasets: [{
            label: 'Total Tagihan',
            data: [<?php foreach($chart_data as $c){ echo "$c->total_tagihan,"; } ?>],
            backgroundColor: 'rgba(78, 115, 223, 0.7)'
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
    }
});
</script>
