<div class="container-fluid mt-4">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0"><?= isset($vendor) ? 'Edit Vendor' : 'Tambah Vendor' ?></h4>
                </div>
                <div class="card-body">
                    <form action="" method="post">
                        <div class="mb-3">
                            <label for="nama_vendor" class="form-label">Nama Vendor</label>
                            <input type="text" name="nama_vendor" id="nama_vendor" class="form-control" value="<?= $vendor->nama_vendor ?? '' ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="kode_vendor" class="form-label">Kode Vendor</label>
                            <input type="text" name="kode_vendor" id="kode_vendor" class="form-control" value="<?= $vendor->kode_vendor ?? '' ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="alamat_vendor" class="form-label">Alamat</label>
                            <textarea name="alamat_vendor" id="alamat_vendor" class="form-control"><?= $vendor->alamat_vendor ?? '' ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" id="status" class="form-select">
                                <option value="aktif" <?= (isset($vendor) && $vendor->status=='aktif')?'selected':'' ?>>Aktif</option>
                                <option value="nonaktif" <?= (isset($vendor) && $vendor->status=='nonaktif')?'selected':'' ?>>Nonaktif</option>
                            </select>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-success">
                                <?= isset($vendor) ? 'Update' : 'Simpan' ?>
                            </button>
                            <a href="<?= site_url('admin/vendor') ?>" class="btn btn-secondary">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
