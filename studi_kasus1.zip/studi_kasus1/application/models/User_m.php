<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_m extends CI_Model {

    protected $table = 'master_user';

    // Ambil semua user beserta nama vendor jika ada
    public function get_all() {
        $this->db->select('u.*, v.nama_vendor');
        $this->db->from('master_user u');
        $this->db->join('vendor v', 'v.id_vendor = u.id_vendor', 'left');
        $query = $this->db->get();
        return $query->result();
    }

    // Ambil user by id
    public function get_by_id($id) {
        return $this->db->get_where($this->table, ['id_user' => $id])->row();
    }

    // Tambah user baru
    public function insert($data) {
        $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        return $this->db->insert($this->table, $data);
    }

    // Update user
    public function update($id, $data) {
        if(isset($data['password']) && !empty($data['password'])){
            $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
        } else {
            unset($data['password']); // jangan ubah password kalau kosong
        }
        $this->db->where('id_user', $id);
        return $this->db->update($this->table, $data);
    }

    // Hapus user
    public function delete($id) {
        return $this->db->delete($this->table, ['id_user' => $id]);
    }

    // Ambil user by username (untuk login)
    public function get_by_username($username) {
        return $this->db->get_where($this->table, ['username' => $username])->row();
    }
}
