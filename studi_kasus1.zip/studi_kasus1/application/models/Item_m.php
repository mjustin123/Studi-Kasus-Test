<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item_m extends CI_Model {

    protected $table = 'master_item';

    public function get_all(){
        return $this->db->where('status','aktif')->get('master_item')->result();
    }

    public function get($id) {
        return $this->db->get_where($this->table, ['id_item'=>$id])->row();
    }

    public function insert($data) {
        $this->db->insert($this->table, $data);
    }

    public function update($id, $data) {
        $this->db->where('id_item', $id);
        $this->db->update($this->table, $data);
    }

    public function delete($id) {
        $this->db->where('id_item', $id);
        $this->db->delete($this->table);
    }

    public function get_all_count() {
        return $this->db->count_all('master_item');
    }
}
