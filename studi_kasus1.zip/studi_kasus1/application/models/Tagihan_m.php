<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tagihan_m extends CI_Model {

    protected $table = 'master_user';

    public function get_total_confirmed() {
        return $this->db->where('status_verifikasi','confirmed')
                        ->count_all_results('tagihan');
    }

    public function get_all_verified($start_date=null, $end_date=null){
        $this->db->select('t.*, v.nama_vendor');
        $this->db->from('tagihan t');
        $this->db->join('vendor v','v.id_vendor = t.id_vendor');
        $this->db->where('t.status_verifikasi','confirmed');

        if($start_date) $this->db->where('t.tanggal_tagihan >=', $start_date);
        if($end_date) $this->db->where('t.tanggal_tagihan <=', $end_date);

        $this->db->order_by('t.tanggal_tagihan','DESC');
        return $this->db->get()->result();
    }

    public function get_chart_data($start_date=null, $end_date=null){
        $this->db->select('v.nama_vendor, SUM(t.total_tagihan) as total_tagihan');
        $this->db->from('tagihan t');
        $this->db->join('vendor v','v.id_vendor = t.id_vendor');
        $this->db->where('t.status_verifikasi','confirmed');

        if($start_date) $this->db->where('t.tanggal_tagihan >=', $start_date);
        if($end_date) $this->db->where('t.tanggal_tagihan <=', $end_date);

        $this->db->group_by('t.id_vendor');
        return $this->db->get()->result();
    }

    // Ambil semua tagihan untuk vendor tertentu
    public function get_by_vendor($id_vendor){
        $this->db->select('t.*, GROUP_CONCAT(CONCAT(i.nama_item, " (", i.jumlah, ")") SEPARATOR ", ") as items');
        $this->db->from('tagihan t');
        $this->db->join('tagihan_item i','i.id_tagihan=t.id_tagihan','left');
        $this->db->where('t.id_vendor', $id_vendor);
        $this->db->group_by('t.id_tagihan');
        $this->db->order_by('t.tanggal_tagihan','DESC');
        return $this->db->get()->result();
    }

    public function insert_tagihan($data){
        $this->db->insert('tagihan', $data);
        return $this->db->insert_id();
    }

    public function insert_item($data){
        $this->db->insert('tagihan_item', $data);
    }

    public function update_tagihan($id, $data){
        $this->db->where('id_tagihan', $id);
        $this->db->update('tagihan', $data);
    }

    public function get($id)
    {
        return $this->db->get_where('tagihan', ['id_tagihan' => $id])->row();
    }

    // Ambil item-item tagihan
    public function get_items($id_tagihan)
    {
        return $this->db->select('ti.*, mi.nama_item')
                        ->from('tagihan_item ti')
                        ->join('master_item mi', 'mi.id_item = ti.id_item', 'left')
                        ->where('ti.id_tagihan', $id_tagihan)
                        ->get()
                        ->result();
    }

    // Simpan tagihan baru
    public function insert($data)
    {
        $this->db->insert('tagihan', $data);
        return $this->db->insert_id();
    }

    // Update tagihan
    public function update($id_tagihan, $data)
    {
        $this->db->where('id_tagihan', $id_tagihan)->update('tagihan', $data);
    }

    // Hapus semua item dulu (untuk update)
    public function delete_items($id_tagihan)
    {
        $this->db->where('id_tagihan', $id_tagihan)->delete('tagihan_item');
    }
}
