<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-11-30 04:03:28 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:28 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:28 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2025-11-30 04:03:30 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:30 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:50 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:50 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:51 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:51 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:51 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:51 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:51 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:51 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:52 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:52 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:52 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:52 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:52 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:52 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:52 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:52 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:52 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:52 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:52 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:52 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:53 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:53 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:53 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:53 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:53 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:53 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:53 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:53 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:03:53 --> Could not find the specified $config['composer_autoload'] path: C:\laragon\www\studi_kasus1\vendor/autoload.php
ERROR - 2025-11-30 04:03:53 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:04:26 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:04:27 --> 404 Page Not Found: Auth/index
ERROR - 2025-11-30 04:20:42 --> 404 Page Not Found: Assets/img
ERROR - 2025-11-30 04:24:56 --> Query error: Table 'studi_kasus1.user' doesn't exist - Invalid query: SELECT *
FROM `user`
WHERE `username` = 'admin'
ERROR - 2025-11-30 04:25:36 --> Severity: Warning --> Undefined property: Admin::$User_model C:\laragon\www\studi_kasus1\application\controllers\Admin.php 106
ERROR - 2025-11-30 04:25:36 --> Severity: error --> Exception: Call to a member function get_all() on null C:\laragon\www\studi_kasus1\application\controllers\Admin.php 106
ERROR - 2025-11-30 04:25:45 --> Severity: Warning --> Undefined property: Admin::$user_m C:\laragon\www\studi_kasus1\application\controllers\Admin.php 106
ERROR - 2025-11-30 04:25:45 --> Severity: error --> Exception: Call to a member function get_all() on null C:\laragon\www\studi_kasus1\application\controllers\Admin.php 106
ERROR - 2025-11-30 04:26:20 --> Severity: Warning --> Undefined property: Admin::$Vendor_model C:\laragon\www\studi_kasus1\application\controllers\Admin.php 128
ERROR - 2025-11-30 04:26:20 --> Severity: error --> Exception: Call to a member function get_all() on null C:\laragon\www\studi_kasus1\application\controllers\Admin.php 128
ERROR - 2025-11-30 04:42:03 --> 404 Page Not Found: Admin/tagihan
ERROR - 2025-11-30 04:44:53 --> Severity: error --> Exception: syntax error, unexpected token "public", expecting end of file C:\laragon\www\studi_kasus1\application\controllers\Admin.php 62
ERROR - 2025-11-30 04:49:19 --> Severity: Warning --> Undefined property: Vendor::$Tagihan_model C:\laragon\www\studi_kasus1\application\controllers\Vendor.php 20
ERROR - 2025-11-30 04:49:19 --> Severity: error --> Exception: Call to a member function get_by_vendor() on null C:\laragon\www\studi_kasus1\application\controllers\Vendor.php 20
ERROR - 2025-11-30 04:50:58 --> 404 Page Not Found: Vendor/tagihan
ERROR - 2025-11-30 04:52:42 --> Severity: Warning --> Undefined property: Vendor::$Tagihan_model C:\laragon\www\studi_kasus1\application\controllers\Vendor.php 35
ERROR - 2025-11-30 04:52:42 --> Severity: error --> Exception: Call to a member function get_by_vendor() on null C:\laragon\www\studi_kasus1\application\controllers\Vendor.php 35
ERROR - 2025-11-30 04:55:59 --> Severity: Warning --> Undefined property: Vendor::$item_m C:\laragon\www\studi_kasus1\application\controllers\Vendor.php 62
ERROR - 2025-11-30 04:55:59 --> Severity: error --> Exception: Call to a member function get_all() on null C:\laragon\www\studi_kasus1\application\controllers\Vendor.php 62
ERROR - 2025-11-30 04:56:13 --> Query error: Table 'studi_kasus1.item' doesn't exist - Invalid query: SELECT *
FROM `item`
WHERE `status` = 'aktif'
ERROR - 2025-11-30 04:56:52 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`studi_kasus1`.`tagihan_item`, CONSTRAINT `tagihan_item_ibfk_2` FOREIGN KEY (`id_item`) REFERENCES `master_item` (`id_item`) ON DELETE RESTRICT) - Invalid query: INSERT INTO `tagihan_item` (`id_tagihan`, `nama_item`, `jumlah`, `harga`) VALUES (1, 'Baut M5', '2', '500.00')
ERROR - 2025-11-30 04:58:08 --> Query error: Duplicate entry 'test001' for key 'tagihan.nomor_tagihan' - Invalid query: INSERT INTO `tagihan` (`nomor_tagihan`, `tanggal_tagihan`, `id_vendor`, `total_tagihan`, `status_verifikasi`, `file_lampiran`) VALUES ('test001', '2025-12-01', '1', 0, 'draft', 'photo_2025-11-12_12-05-311.jpg')
ERROR - 2025-11-30 05:00:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Item_model C:\laragon\www\studi_kasus1\system\core\Loader.php 349
ERROR - 2025-11-30 05:03:55 --> Severity: error --> Exception: Call to undefined method Tagihan_m::get() C:\laragon\www\studi_kasus1\application\controllers\Vendor.php 141
ERROR - 2025-11-30 05:09:13 --> Severity: Warning --> Undefined property: stdClass::$lampiran C:\laragon\www\studi_kasus1\application\views\vendor\tagihan_form.php 69
ERROR - 2025-11-30 05:10:51 --> Severity: Warning --> Undefined property: stdClass::$lampiran C:\laragon\www\studi_kasus1\application\controllers\Vendor.php 159
